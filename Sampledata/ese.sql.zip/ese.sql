-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 09. Dez 2014 um 21:50
-- Server Version: 5.6.20
-- PHP-Version: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Datenbank: `ese`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `adapplication`
--

CREATE TABLE IF NOT EXISTS `adapplication` (
`id` bigint(20) NOT NULL,
  `favored` tinyint(1) NOT NULL,
  `message` text,
  `smoker` tinyint(1) NOT NULL,
  `timeLimitation` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `ad_id` bigint(20) DEFAULT NULL,
  `applicant_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `adapplication`
--

INSERT INTO `adapplication` (`id`, `favored`, `message`, `smoker`, `timeLimitation`, `title`, `ad_id`, `applicant_id`) VALUES
(1, 0, 'Hey, kann ich einziehen?', 0, 'sobald wie möglich', NULL, 2, 5),
(2, 0, 'This is seriously awesome!', 0, '12/31/2014', NULL, 8, 1),
(3, 1, 'Yes please! Invite me! I am too cool!', 0, 'sobald wie möglich', NULL, 8, 2),
(4, 0, 'Hello! Can I visit?', 0, 'sobald wie möglich', NULL, 8, 4),
(5, 0, 'Hey!', 0, 'sobald wie möglich', NULL, 4, 6);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `advertisement`
--

CREATE TABLE IF NOT EXISTS `advertisement` (
`id` bigint(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `ageRange` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `description_ad` longtext,
  `description_room` longtext,
  `description_us` longtext,
  `furnished` tinyint(1) NOT NULL,
  `genderWeLookFor` varchar(255) DEFAULT NULL,
  `hasBalcony` tinyint(1) NOT NULL,
  `hasBuiltInCloset` tinyint(1) NOT NULL,
  `hasCables` tinyint(1) NOT NULL,
  `hasDishwasher` tinyint(1) NOT NULL,
  `hasLaundry` tinyint(1) NOT NULL,
  `hasPets` tinyint(1) NOT NULL,
  `isToBalcony` tinyint(1) NOT NULL,
  `kanton` varchar(255) DEFAULT NULL,
  `nmbrOfRoommates` int(11) NOT NULL,
  `plz` int(11) NOT NULL,
  `publicVisit` varchar(255) DEFAULT NULL,
  `roomPrice` int(11) NOT NULL,
  `roomSpace` float NOT NULL,
  `rooms` float NOT NULL,
  `smoker` varchar(255) DEFAULT NULL,
  `smokingInside` tinyint(1) NOT NULL,
  `start` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `until` varchar(255) DEFAULT NULL,
  `wgGender` varchar(255) DEFAULT NULL,
  `wgType` varchar(255) DEFAULT NULL,
  `whoWeAreLookingFor` longtext,
  `wlan` tinyint(1) NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL,
  `mainPic_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Daten für Tabelle `advertisement`
--

INSERT INTO `advertisement` (`id`, `address`, `ageRange`, `city`, `creationDate`, `description`, `description_ad`, `description_room`, `description_us`, `furnished`, `genderWeLookFor`, `hasBalcony`, `hasBuiltInCloset`, `hasCables`, `hasDishwasher`, `hasLaundry`, `hasPets`, `isToBalcony`, `kanton`, `nmbrOfRoommates`, `plz`, `publicVisit`, `roomPrice`, `roomSpace`, `rooms`, `smoker`, `smokingInside`, `start`, `title`, `until`, `wgGender`, `wgType`, `whoWeAreLookingFor`, `wlan`, `creator_id`, `mainPic_id`) VALUES
(1, 'Kramgasse 20', '', 'Bern', '2014-12-09 21:18:39', NULL, 'Kleine Wohnung im Herzen von Bern.', 'Das Zimmer ist meine Abstellkammer', '55 Jähriger berufstätiger Mann.', 0, 'dontcare', 0, 0, 0, 0, 0, 0, 0, 'Bern', 1, 3000, '01.01.2015', 250, 8, 1.5, '', 1, 'Per sofort', '8m&sup2 Zimmer in einer 2er-WG in Bern für 250 CHF', 'Unbefristet', 'male', 'undef', 'Du bist unkompliziert und willst in meiner Kammer wohnen.', 1, 1, 1),
(2, 'Gurzelngasse 5', '18-28', 'Solothurn', '2014-12-09 21:20:51', NULL, 'Geräumige Wohnung.', 'Gutes, helles Zimmer. Nicht so gross', 'Aufgestellte Leute die dich suchen!', 0, 'male', 1, 0, 1, 1, 1, 1, 0, 'Solothurn', 3, 4500, 'Keiner', 720, 15, 4.5, 'nonsmoker', 0, '12/31/2014', '15m&sup2 Zimmer in einer 4er-WG in Solothurn für 720 CHF', 'Unbefristet', 'mixed', 'calm', 'Dich!', 1, 1, 3),
(3, 'Bahnhofstrasse 3', '', 'Zürich', '2014-12-09 21:22:45', NULL, '', '', '', 0, 'dontcare', 1, 0, 0, 1, 1, 0, 0, 'Zürich', 2, 8000, 'Keiner', 950, 13, 4, '', 0, 'Per sofort', '13m&sup2 Zimmer in einer 3er-WG in Zürich für 950 CHF', 'Unbefristet', '', 'wild', '', 1, 2, 7),
(4, 'Im Rötel 3', '18-99', 'Zug', '2014-12-09 21:25:28', NULL, 'Riesen Schloss!', 'Riesen Zimmer!', 'Zuger Adelsfamilie', 0, 'dontcare', 1, 1, 1, 1, 1, 1, 1, 'Zug', 3, 6300, '01.02.2015', 5000, 18, 21, '', 1, 'Per sofort', '18m&sup2 Zimmer in einer 4er-WG in Zug für 5000 CHF', '02/28/2015', 'mixed', 'undef', 'Edler Mensch!', 1, 2, 11),
(5, 'Marktgasse 17', '', 'Bern', '2014-12-09 21:26:15', NULL, '', '', '', 0, 'dontcare', 0, 0, 0, 0, 0, 0, 0, 'Bern', 3, 3000, 'Keiner', 600, 12, 5.5, '', 0, 'Per sofort', '12m&sup2 Zimmer in einer 4er-WG in Bern für 600 CHF', 'Unbefristet', '', 'wild', '', 0, 3, NULL),
(6, 'Rötistrasse 15', '', 'Oberdorf', '2014-12-09 21:28:27', NULL, 'Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....', 'Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....', 'Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....', 0, 'dontcare', 0, 0, 0, 0, 0, 0, 0, 'Solothurn', 2, 4515, 'Keiner', 650, 21, 4, '', 0, 'Per sofort', '21m&sup2 Zimmer in einer 3er-WG in Oberdorf für 650 CHF', 'Unbefristet', '', 'undef', 'Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....', 0, 4, 14),
(7, 'Marktgasse 8', '', 'Bern', '2014-12-09 21:29:43', NULL, 'Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....', '', '', 1, 'dontcare', 0, 0, 0, 1, 1, 0, 0, 'Bern', 1, 3000, 'Keiner', 500, 15, 2.5, '', 1, '12/31/2014', '15m&sup2 Zimmer in einer 2er-WG in Bern für 500 CHF', 'Unbefristet', '', 'undef', 'Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....Viel Beispieltext.....', 0, 5, 18),
(8, 'Marktgasse 27', '18-99', 'Bern', '2014-12-09 21:37:26', NULL, 'This is the Ese Villa! It is big and really nice! There is really everything you will ever need!', 'The Room is huge, and there is a pool right outside of your window!', 'We are the ese team. We are awesome! Join the force !', 1, 'dontcare', 1, 1, 1, 1, 1, 1, 1, 'Bern', 3, 3000, 'Keiner', 700, 25, 5.5, 'dontcare', 1, 'Per sofort', '25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF', 'Unbefristet', 'mixed', 'wild', 'We are looking for you! A nice person!', 1, 6, 22),
(9, 'Kramgasse 12', '', 'Bern', '2014-12-09 21:48:02', NULL, '', '', '', 0, 'dontcare', 0, 0, 0, 0, 0, 0, 0, 'Bern', 2, 3001, 'Keiner', 500, 12, 2.5, '', 0, 'Per sofort', 'QuickAdWithCustomTitle', 'Unbefristet', '', 'undef', '', 0, 6, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `advertisement_appointments`
--

CREATE TABLE IF NOT EXISTS `advertisement_appointments` (
  `Advertisement_id` bigint(20) NOT NULL,
  `appointments` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `advertisement_appointments`
--

INSERT INTO `advertisement_appointments` (`Advertisement_id`, `appointments`) VALUES
(8, 1),
(4, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `advertisement_bookmarks`
--

CREATE TABLE IF NOT EXISTS `advertisement_bookmarks` (
  `Advertisement_id` bigint(20) NOT NULL,
  `bookmarks` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `advertisement_picture`
--

CREATE TABLE IF NOT EXISTS `advertisement_picture` (
  `Advertisement_id` bigint(20) NOT NULL,
  `pictures_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `advertisement_picture`
--

INSERT INTO `advertisement_picture` (`Advertisement_id`, `pictures_id`) VALUES
(1, 2),
(2, 4),
(2, 5),
(2, 6),
(3, 8),
(3, 9),
(3, 10),
(4, 12),
(4, 13),
(6, 15),
(6, 16),
(6, 17),
(7, 19),
(7, 20),
(7, 21),
(8, 23),
(8, 24);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
`id` bigint(20) NOT NULL,
  `ad` bigint(20) DEFAULT NULL,
  `additionalInfosForTheVisitors` varchar(255) DEFAULT NULL,
  `blockLength` varchar(255) DEFAULT NULL,
  `appointmentDate_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `appointment`
--

INSERT INTO `appointment` (`id`, `ad`, `additionalInfosForTheVisitors`, `blockLength`, `appointmentDate_id`) VALUES
(1, 8, 'Come come! It is nice.', NULL, 1),
(2, 4, 'Come come! No parking!', NULL, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `appointmentaccepted`
--

CREATE TABLE IF NOT EXISTS `appointmentaccepted` (
`id` bigint(20) NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  `rejected` tinyint(1) NOT NULL,
  `appointment_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `appointmentdate`
--

CREATE TABLE IF NOT EXISTS `appointmentdate` (
`id` bigint(20) NOT NULL,
  `day` varchar(255) DEFAULT NULL,
  `endHour` varchar(255) DEFAULT NULL,
  `startHour` varchar(255) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Daten für Tabelle `appointmentdate`
--

INSERT INTO `appointmentdate` (`id`, `day`, `endHour`, `startHour`) VALUES
(1, '26/12/2014', '', '13:40'),
(2, '09/12/2014', '', '21:41');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `appointment_user`
--

CREATE TABLE IF NOT EXISTS `appointment_user` (
  `usersInvitations_id` bigint(20) NOT NULL,
  `invitations_id` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Daten für Tabelle `appointment_user`
--

INSERT INTO `appointment_user` (`usersInvitations_id`, `invitations_id`) VALUES
(1, 2),
(1, 4),
(2, 6);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bookmark`
--

CREATE TABLE IF NOT EXISTS `bookmark` (
`id` bigint(20) NOT NULL,
  `ad` bigint(20) DEFAULT NULL,
  `bookmarker_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Daten für Tabelle `bookmark`
--

INSERT INTO `bookmark` (`id`, `ad`, `bookmarker_id`) VALUES
(1, 2, 5),
(2, 8, 1),
(3, 8, 2),
(4, 1, 6),
(5, 7, 6);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `customfilterad`
--

CREATE TABLE IF NOT EXISTS `customfilterad` (
`id` bigint(20) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `ageRange` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `description_ad` varchar(255) DEFAULT NULL,
  `description_room` varchar(255) DEFAULT NULL,
  `description_us` varchar(255) DEFAULT NULL,
  `furnished` tinyint(1) NOT NULL,
  `genderWeLookFor` varchar(255) DEFAULT NULL,
  `hasBalcony` tinyint(1) NOT NULL,
  `hasBuiltInCloset` tinyint(1) NOT NULL,
  `hasCables` tinyint(1) NOT NULL,
  `hasDishwasher` tinyint(1) NOT NULL,
  `hasLaundry` tinyint(1) NOT NULL,
  `hasPets` tinyint(1) NOT NULL,
  `isToBalcony` tinyint(1) NOT NULL,
  `kanton` varchar(255) DEFAULT NULL,
  `nmbrOfRoommates` int(11) NOT NULL,
  `plz` int(11) NOT NULL,
  `roomPrice` int(11) NOT NULL,
  `roomSpace` int(11) NOT NULL,
  `rooms` int(11) NOT NULL,
  `smoker` varchar(255) DEFAULT NULL,
  `smokingInside` tinyint(1) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `wgGender` varchar(255) DEFAULT NULL,
  `wgType` varchar(255) DEFAULT NULL,
  `whoWeAreLookingFor` varchar(255) DEFAULT NULL,
  `wlan` tinyint(1) NOT NULL,
  `creator_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `message`
--

CREATE TABLE IF NOT EXISTS `message` (
`id` bigint(20) NOT NULL,
  `accepted` tinyint(1) NOT NULL,
  `appointedAppointment` bigint(20) DEFAULT NULL,
  `messageText` longtext,
  `readMessage` tinyint(1) NOT NULL,
  `recipientDeleted` tinyint(1) NOT NULL,
  `rejected` tinyint(1) NOT NULL,
  `senderDeleted` tinyint(1) NOT NULL,
  `title` longtext,
  `appointmentInvitations_id` bigint(20) DEFAULT NULL,
  `notifications_id` bigint(20) DEFAULT NULL,
  `recipient_id` bigint(20) DEFAULT NULL,
  `sender_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=10 ;

--
-- Daten für Tabelle `message`
--

INSERT INTO `message` (`id`, `accepted`, `appointedAppointment`, `messageText`, `readMessage`, `recipientDeleted`, `rejected`, `senderDeleted`, `title`, `appointmentInvitations_id`, `notifications_id`, `recipient_id`, `sender_id`) VALUES
(1, 0, NULL, 'Hey, MrA, du hast einen neuen Interessenten für dein Ad mit dem Titel 15m&sup2 Zimmer in einer 4er-WG in Solothurn für 720 CHFclicke <a href="interessentDetails?applicationId=1">HIER </a> um die Bewerbung anzusehen.', 0, 0, 0, 0, 'Neuen Interessenten für, 15m&sup2 Zimmer in einer 4er-WG in Solothurn für 720 CHF', NULL, 1, NULL, NULL),
(2, 0, NULL, 'Ich habe eine Frage bezüglich des Ads <a href="adprofile?adId=8">25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF</a> :  <br>WOOOOOW. Does it have a place for my lambo?', 0, 0, 0, 0, 'WooooW', NULL, NULL, 6, 1),
(3, 0, NULL, 'Hey, MrEse, du hast einen neuen Interessenten für dein Ad mit dem Titel 25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHFclicke <a href="interessentDetails?applicationId=2">HIER </a> um die Bewerbung anzusehen.', 0, 0, 0, 0, 'Neuen Interessenten für, 25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF', NULL, 6, NULL, NULL),
(4, 0, NULL, 'Hey, MrEse, du hast einen neuen Interessenten für dein Ad mit dem Titel 25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHFclicke <a href="interessentDetails?applicationId=3">HIER </a> um die Bewerbung anzusehen.', 0, 0, 0, 0, 'Neuen Interessenten für, 25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF', NULL, 6, NULL, NULL),
(5, 0, NULL, 'Hey, MrEse, du hast einen neuen Interessenten für dein Ad mit dem Titel 25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHFclicke <a href="interessentDetails?applicationId=4">HIER </a> um die Bewerbung anzusehen.', 0, 0, 0, 0, 'Neuen Interessenten für, 25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF', NULL, 6, NULL, NULL),
(6, 0, 1, 'Hallo, du wurdest von MrEse Ese zur besichtigung des Ads: <a href="adprofile?adId=8">25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF</a> eingeladen<br> der Termin wäre am 26/12/2014 um 13:40 Einladungsnachricht des Zimmerbesitzers: <br> Come come! It is nice.', 0, 0, 0, 0, 'Einladung zu einer Wohnungbesichtigung', 2, NULL, NULL, NULL),
(7, 0, 1, 'Hallo, du wurdest von MrEse Ese zur besichtigung des Ads: <a href="adprofile?adId=8">25m&sup2 Zimmer in einer 4er-WG in Bern für 700 CHF</a> eingeladen<br> der Termin wäre am 26/12/2014 um 13:40 Einladungsnachricht des Zimmerbesitzers: <br> Come come! It is nice.', 0, 0, 0, 0, 'Einladung zu einer Wohnungbesichtigung', 4, NULL, NULL, NULL),
(8, 0, NULL, 'Hey, MrB, du hast einen neuen Interessenten für dein Ad mit dem Titel 18m&sup2 Zimmer in einer 4er-WG in Zug für 5000 CHFclicke <a href="interessentDetails?applicationId=5">HIER </a> um die Bewerbung anzusehen.', 0, 0, 0, 0, 'Neuen Interessenten für, 18m&sup2 Zimmer in einer 4er-WG in Zug für 5000 CHF', NULL, 2, NULL, NULL),
(9, 0, 2, 'Hallo, du wurdest von MrB MrB zur besichtigung des Ads: <a href="adprofile?adId=4">18m&sup2 Zimmer in einer 4er-WG in Zug für 5000 CHF</a> eingeladen<br> der Termin wäre am 09/12/2014 um 21:41 Einladungsnachricht des Zimmerbesitzers: <br> Come come! No parking!', 0, 0, 0, 0, 'Einladung zu einer Wohnungbesichtigung', 6, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `note`
--

CREATE TABLE IF NOT EXISTS `note` (
`id` bigint(20) NOT NULL,
  `text` longtext,
  `applicant_id` bigint(20) DEFAULT NULL,
  `appointment_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `picture`
--

CREATE TABLE IF NOT EXISTS `picture` (
`id` bigint(20) NOT NULL,
  `absoluteFilePath` varchar(255) DEFAULT NULL,
  `isMainPic` tinyint(1) NOT NULL,
  `relativeFilePath` varchar(255) DEFAULT NULL,
  `ad_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Daten für Tabelle `picture`
--

INSERT INTO `picture` (`id`, `absoluteFilePath`, `isMainPic`, `relativeFilePath`, `ad_id`) VALUES
(1, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\a@a.ch\\250Kramgasse 20Bern200Kramgasse 20Bernabstellkammer_voll.jpg', 1, '/img/adPictures/a@a.ch/250Kramgasse 20Bern200Kramgasse 20Bernabstellkammer_voll.jpg', NULL),
(2, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\a@a.ch\\250Kramgasse 20Bern200Kramgasse 20BernAbstellkammer-199x300.jpg', 0, '/img/adPictures/a@a.ch/250Kramgasse 20Bern200Kramgasse 20BernAbstellkammer-199x300.jpg', NULL),
(3, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\a@a.ch\\720Gurzelngasse 5Solothurn350Kramgasse 1Bern850Bizusstrasse 12Zürichimg1Ad2.jpg', 1, '/img/adPictures/a@a.ch/720Gurzelngasse 5Solothurn350Kramgasse 1Bern850Bizusstrasse 12Zürichimg1Ad2.jpg', NULL),
(4, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\a@a.ch\\720Gurzelngasse 5Solothurn350Kramgasse 1Bern900Murtenstrasse 99Bernimg4Ad3.jpg', 0, '/img/adPictures/a@a.ch/720Gurzelngasse 5Solothurn350Kramgasse 1Bern900Murtenstrasse 99Bernimg4Ad3.jpg', NULL),
(5, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\a@a.ch\\720Gurzelngasse 5Solothurn350Kramgasse 1Bern1000Bahnhofstrasse 2Baselimg2Ad4.jpg', 0, '/img/adPictures/a@a.ch/720Gurzelngasse 5Solothurn350Kramgasse 1Bern1000Bahnhofstrasse 2Baselimg2Ad4.jpg', NULL),
(6, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\a@a.ch\\720Gurzelngasse 5Solothurn400Badusstrasse 3Chur505Bärengraben 4Bernimg2-ad1.jpg', 0, '/img/adPictures/a@a.ch/720Gurzelngasse 5Solothurn400Badusstrasse 3Chur505Bärengraben 4Bernimg2-ad1.jpg', NULL),
(7, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn600Monbijoustrasse 71Bernimg1-ad1.jpg', 1, '/img/adPictures/b@b.ch/950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn600Monbijoustrasse 71Bernimg1-ad1.jpg', NULL),
(8, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn600Monbijoustrasse 71Bernimg2-ad1.jpg', 0, '/img/adPictures/b@b.ch/950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn600Monbijoustrasse 71Bernimg2-ad1.jpg', NULL),
(9, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn600Monbijoustrasse 71Bernimg3-ad1.jpg', 0, '/img/adPictures/b@b.ch/950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn600Monbijoustrasse 71Bernimg3-ad1.jpg', NULL),
(10, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn1000Bahnhofstrasse 2Baselimg3Ad4.jpg', 0, '/img/adPictures/b@b.ch/950Bahnhofstrasse 3Zürich600gurzelngasse 5Solothurn1000Bahnhofstrasse 2Baselimg3Ad4.jpg', NULL),
(11, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\5000Im Rötel 3Zug9000Im Rötel 3ZugSchloss1.png', 1, '/img/adPictures/b@b.ch/5000Im Rötel 3Zug9000Im Rötel 3ZugSchloss1.png', NULL),
(12, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\5000Im Rötel 3Zug9000Im Rötel 3ZugSchlossROom.jpg', 0, '/img/adPictures/b@b.ch/5000Im Rötel 3Zug9000Im Rötel 3ZugSchlossROom.jpg', NULL),
(13, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\b@b.ch\\5000Im Rötel 3Zug9000Im Rötel 3ZugSchlossRoom2.jpg', 0, '/img/adPictures/b@b.ch/5000Im Rötel 3Zug9000Im Rötel 3ZugSchlossRoom2.jpg', NULL),
(14, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\d@d.ch\\650Rötistrasse 15Oberdorf650Marktgasse 12Bern900Murtenstrasse 99Bernimg2Ad3.jpg', 1, '/img/adPictures/d@d.ch/650Rötistrasse 15Oberdorf650Marktgasse 12Bern900Murtenstrasse 99Bernimg2Ad3.jpg', NULL),
(15, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\d@d.ch\\650Rötistrasse 15Oberdorf650Marktgasse 12Bern900Murtenstrasse 99Bernimg3Ad3.jpg', 0, '/img/adPictures/d@d.ch/650Rötistrasse 15Oberdorf650Marktgasse 12Bern900Murtenstrasse 99Bernimg3Ad3.jpg', NULL),
(16, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\d@d.ch\\650Rötistrasse 15Oberdorf650Marktgasse 12Bern900Murtenstrasse 99Bernimg4Ad3.jpg', 0, '/img/adPictures/d@d.ch/650Rötistrasse 15Oberdorf650Marktgasse 12Bern900Murtenstrasse 99Bernimg4Ad3.jpg', NULL),
(17, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\d@d.ch\\650Rötistrasse 15Oberdorf650Marktgasse 12Bern1000Bahnhofstrasse 2Baselimg4Ad4.jpg', 0, '/img/adPictures/d@d.ch/650Rötistrasse 15Oberdorf650Marktgasse 12Bern1000Bahnhofstrasse 2Baselimg4Ad4.jpg', NULL),
(18, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\e@e.ch\\500Marktgasse 8Bern800Murtenstrasse 13Bern900Murtenstrasse 99Bernimg2Ad3.jpg', 1, '/img/adPictures/e@e.ch/500Marktgasse 8Bern800Murtenstrasse 13Bern900Murtenstrasse 99Bernimg2Ad3.jpg', NULL),
(19, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\e@e.ch\\500Marktgasse 8Bern800Murtenstrasse 13Bern900Murtenstrasse 99Bernimg1Ad3.jpg', 0, '/img/adPictures/e@e.ch/500Marktgasse 8Bern800Murtenstrasse 13Bern900Murtenstrasse 99Bernimg1Ad3.jpg', NULL),
(20, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\e@e.ch\\500Marktgasse 8Bern800Murtenstrasse 13Bern900Murtenstrasse 99Bernimg4Ad3.jpg', 0, '/img/adPictures/e@e.ch/500Marktgasse 8Bern800Murtenstrasse 13Bern900Murtenstrasse 99Bernimg4Ad3.jpg', NULL),
(21, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\e@e.ch\\500Marktgasse 8Bern800Murtenstrasse 13Bern1000Bahnhofstrasse 2Baselimg2Ad4.jpg', 0, '/img/adPictures/e@e.ch/500Marktgasse 8Bern800Murtenstrasse 13Bern1000Bahnhofstrasse 2Baselimg2Ad4.jpg', NULL),
(22, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\ese@ese.ch\\700Marktgasse 27Bernluxurioese-villa-.jpg', 1, '/img/adPictures/ese@ese.ch/700Marktgasse 27Bernluxurioese-villa-.jpg', NULL),
(23, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\ese@ese.ch\\700Marktgasse 27BernEseVilla1.jpg', 0, '/img/adPictures/ese@ese.ch/700Marktgasse 27BernEseVilla1.jpg', NULL),
(24, 'C:\\Users\\Ice\\eseunibe\\ese2014-team2\\Skeleton\\src\\main\\webapp\\img\\adPictures\\ese@ese.ch\\700Marktgasse 27BernEseVilla2.jpg', 0, '/img/adPictures/ese@ese.ch/700Marktgasse 27BernEseVilla2.jpg', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE IF NOT EXISTS `user` (
`id` bigint(20) NOT NULL,
  `EMAIL` varchar(100) NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `firstName` varchar(255) DEFAULT NULL,
  `lastName` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `exampleAd_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `user`
--

INSERT INTO `user` (`id`, `EMAIL`, `enabled`, `firstName`, `lastName`, `password`, `exampleAd_id`) VALUES
(1, 'a@a.ch', 1, 'MrA', 'MrA', '$2a$10$3Wv67zf/T8ObdmTSJgHKsuuOq5aIp/VahXos.cPj69x5lkRY0Mcn.', NULL),
(2, 'b@b.ch', 1, 'MrB', 'MrB', '$2a$10$VqpUPgbkqeS4KPJycRg8YOzAqSfwq0JZk1bOGiml0x2oWWKv5YSNC', NULL),
(3, 'c@c.ch', 1, 'MrC', 'MrC', '$2a$10$arODGcts92xaTu7lsZjCC.dHua8fItiRDXApiP18Ffw65XdsIRagq', NULL),
(4, 'd@d.ch', 1, 'MrD', 'MrD', '$2a$10$CweOHye7PCOIsh1Bykoa/uRIGjtrA4.EV9j9KU1sHA8tmg6ofXd0i', NULL),
(5, 'e@e.ch', 1, 'MrE', 'MrE', '$2a$10$vFxjJt92RA2bc6AylnnZx.vLBfJXgtZryHlJmitP9nHnb6kBlvccC', NULL),
(6, 'ese@ese.ch', 1, 'MrEse', 'Ese', '$2a$10$HDf06OsRyGexp.EtvzPPOeWBMNRWcbvbmPYJBhRl3oBPelh9KAIOK', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user_roles`
--

CREATE TABLE IF NOT EXISTS `user_roles` (
`id` bigint(20) NOT NULL,
  `role` varchar(45) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Daten für Tabelle `user_roles`
--

INSERT INTO `user_roles` (`id`, `role`, `user_id`) VALUES
(1, 'ROLE_USER', 1),
(2, 'ROLE_USER', 2),
(3, 'ROLE_USER', 3),
(4, 'ROLE_USER', 4),
(5, 'ROLE_USER', 5),
(6, 'ROLE_USER', 6);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adapplication`
--
ALTER TABLE `adapplication`
 ADD PRIMARY KEY (`id`), ADD KEY `FK50B6ED0DC9D1A1B1` (`ad_id`), ADD KEY `FK50B6ED0D96C3EEAE` (`applicant_id`);

--
-- Indexes for table `advertisement`
--
ALTER TABLE `advertisement`
 ADD PRIMARY KEY (`id`), ADD KEY `FK27FD01E5B16E0544` (`creator_id`), ADD KEY `FK27FD01E57D0C6C9C` (`mainPic_id`);

--
-- Indexes for table `advertisement_appointments`
--
ALTER TABLE `advertisement_appointments`
 ADD KEY `FK41877CCE7248788F` (`Advertisement_id`);

--
-- Indexes for table `advertisement_bookmarks`
--
ALTER TABLE `advertisement_bookmarks`
 ADD KEY `FK45B1A4237248788F` (`Advertisement_id`);

--
-- Indexes for table `advertisement_picture`
--
ALTER TABLE `advertisement_picture`
 ADD PRIMARY KEY (`Advertisement_id`,`pictures_id`), ADD UNIQUE KEY `pictures_id` (`pictures_id`), ADD KEY `FK8DFBE884E4AEE018` (`pictures_id`), ADD KEY `FK8DFBE8847248788F` (`Advertisement_id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
 ADD PRIMARY KEY (`id`), ADD KEY `FKB7F037F1562CE6F` (`appointmentDate_id`);

--
-- Indexes for table `appointmentaccepted`
--
ALTER TABLE `appointmentaccepted`
 ADD PRIMARY KEY (`id`), ADD KEY `FKFBA818462F7B938F` (`appointment_id`), ADD KEY `FKFBA8184656720145` (`user_id`);

--
-- Indexes for table `appointmentdate`
--
ALTER TABLE `appointmentdate`
 ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment_user`
--
ALTER TABLE `appointment_user`
 ADD KEY `FK48856CAB8484CEB6` (`invitations_id`), ADD KEY `FK48856CAB3748315C` (`usersInvitations_id`);

--
-- Indexes for table `bookmark`
--
ALTER TABLE `bookmark`
 ADD PRIMARY KEY (`id`), ADD KEY `FK7B6209567598C9AD` (`bookmarker_id`);

--
-- Indexes for table `customfilterad`
--
ALTER TABLE `customfilterad`
 ADD PRIMARY KEY (`id`), ADD KEY `FKF135906CB16E0544` (`creator_id`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
 ADD PRIMARY KEY (`id`), ADD KEY `FK9C2397E7B1E5E815` (`appointmentInvitations_id`), ADD KEY `FK9C2397E7BF52E708` (`notifications_id`), ADD KEY `FK9C2397E7AA953037` (`recipient_id`), ADD KEY `FK9C2397E76122429B` (`sender_id`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
 ADD PRIMARY KEY (`id`), ADD KEY `FK25241296C3EEAE` (`applicant_id`), ADD KEY `FK2524122F7B938F` (`appointment_id`);

--
-- Indexes for table `picture`
--
ALTER TABLE `picture`
 ADD PRIMARY KEY (`id`), ADD KEY `FK40C8F4DEC9D1A1B1` (`ad_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
 ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `EMAIL` (`EMAIL`), ADD UNIQUE KEY `EMAIL_2` (`EMAIL`), ADD KEY `FK285FEBD985F184` (`exampleAd_id`);

--
-- Indexes for table `user_roles`
--
ALTER TABLE `user_roles`
 ADD PRIMARY KEY (`id`), ADD KEY `FK7342994956720145` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adapplication`
--
ALTER TABLE `adapplication`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `advertisement`
--
ALTER TABLE `advertisement`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `appointmentaccepted`
--
ALTER TABLE `appointmentaccepted`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `appointmentdate`
--
ALTER TABLE `appointmentdate`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `bookmark`
--
ALTER TABLE `bookmark`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `customfilterad`
--
ALTER TABLE `customfilterad`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `picture`
--
ALTER TABLE `picture`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `user_roles`
--
ALTER TABLE `user_roles`
MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `adapplication`
--
ALTER TABLE `adapplication`
ADD CONSTRAINT `FK50B6ED0D96C3EEAE` FOREIGN KEY (`applicant_id`) REFERENCES `user` (`id`),
ADD CONSTRAINT `FK50B6ED0DC9D1A1B1` FOREIGN KEY (`ad_id`) REFERENCES `advertisement` (`id`);

--
-- Constraints der Tabelle `advertisement`
--
ALTER TABLE `advertisement`
ADD CONSTRAINT `FK27FD01E57D0C6C9C` FOREIGN KEY (`mainPic_id`) REFERENCES `picture` (`id`),
ADD CONSTRAINT `FK27FD01E5B16E0544` FOREIGN KEY (`creator_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `advertisement_appointments`
--
ALTER TABLE `advertisement_appointments`
ADD CONSTRAINT `FK41877CCE7248788F` FOREIGN KEY (`Advertisement_id`) REFERENCES `advertisement` (`id`);

--
-- Constraints der Tabelle `advertisement_bookmarks`
--
ALTER TABLE `advertisement_bookmarks`
ADD CONSTRAINT `FK45B1A4237248788F` FOREIGN KEY (`Advertisement_id`) REFERENCES `advertisement` (`id`);

--
-- Constraints der Tabelle `advertisement_picture`
--
ALTER TABLE `advertisement_picture`
ADD CONSTRAINT `FK8DFBE8847248788F` FOREIGN KEY (`Advertisement_id`) REFERENCES `advertisement` (`id`),
ADD CONSTRAINT `FK8DFBE884E4AEE018` FOREIGN KEY (`pictures_id`) REFERENCES `picture` (`id`);

--
-- Constraints der Tabelle `appointment`
--
ALTER TABLE `appointment`
ADD CONSTRAINT `FKB7F037F1562CE6F` FOREIGN KEY (`appointmentDate_id`) REFERENCES `appointmentdate` (`id`);

--
-- Constraints der Tabelle `appointmentaccepted`
--
ALTER TABLE `appointmentaccepted`
ADD CONSTRAINT `FKFBA818462F7B938F` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`),
ADD CONSTRAINT `FKFBA8184656720145` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `appointment_user`
--
ALTER TABLE `appointment_user`
ADD CONSTRAINT `FK48856CAB3748315C` FOREIGN KEY (`usersInvitations_id`) REFERENCES `appointment` (`id`),
ADD CONSTRAINT `FK48856CAB8484CEB6` FOREIGN KEY (`invitations_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `bookmark`
--
ALTER TABLE `bookmark`
ADD CONSTRAINT `FK7B6209567598C9AD` FOREIGN KEY (`bookmarker_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `customfilterad`
--
ALTER TABLE `customfilterad`
ADD CONSTRAINT `FKF135906CB16E0544` FOREIGN KEY (`creator_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `message`
--
ALTER TABLE `message`
ADD CONSTRAINT `FK9C2397E76122429B` FOREIGN KEY (`sender_id`) REFERENCES `user` (`id`),
ADD CONSTRAINT `FK9C2397E7AA953037` FOREIGN KEY (`recipient_id`) REFERENCES `user` (`id`),
ADD CONSTRAINT `FK9C2397E7B1E5E815` FOREIGN KEY (`appointmentInvitations_id`) REFERENCES `user` (`id`),
ADD CONSTRAINT `FK9C2397E7BF52E708` FOREIGN KEY (`notifications_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `note`
--
ALTER TABLE `note`
ADD CONSTRAINT `FK2524122F7B938F` FOREIGN KEY (`appointment_id`) REFERENCES `appointment` (`id`),
ADD CONSTRAINT `FK25241296C3EEAE` FOREIGN KEY (`applicant_id`) REFERENCES `user` (`id`);

--
-- Constraints der Tabelle `picture`
--
ALTER TABLE `picture`
ADD CONSTRAINT `FK40C8F4DEC9D1A1B1` FOREIGN KEY (`ad_id`) REFERENCES `advertisement` (`id`);

--
-- Constraints der Tabelle `user`
--
ALTER TABLE `user`
ADD CONSTRAINT `FK285FEBD985F184` FOREIGN KEY (`exampleAd_id`) REFERENCES `customfilterad` (`id`);

--
-- Constraints der Tabelle `user_roles`
--
ALTER TABLE `user_roles`
ADD CONSTRAINT `FK7342994956720145` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
